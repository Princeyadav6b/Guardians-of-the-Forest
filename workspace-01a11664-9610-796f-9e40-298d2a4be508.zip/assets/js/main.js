/* ============================================================
   GUARDIANS OF THE FOREST — behaviour
   Everything here is progressive: if a component is missing,
   the script simply skips it. No autoplaying media, ever.
   ============================================================ */
(function () {
  'use strict';

  var $  = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ----------------------------------------------------------
     1. TOAST — small status messages for buttons
     ---------------------------------------------------------- */
  var toastEl = $('#toast');
  var toastTimer = null;
  function toast(message) {
    if (!toastEl) { return; }
    toastEl.textContent = message;
    toastEl.hidden = false;
    window.requestAnimationFrame(function () { toastEl.classList.add('is-visible'); });
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(function () {
      toastEl.classList.remove('is-visible');
      window.setTimeout(function () { toastEl.hidden = true; }, 320);
    }, 4200);
  }

  /* ----------------------------------------------------------
     2. CLIPBOARD — with fallback for older browsers / file://
     ---------------------------------------------------------- */
  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    return new Promise(function (resolve, reject) {
      try {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.top = '-1000px';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        resolve();
      } catch (err) { reject(err); }
    });
  }

  /* ----------------------------------------------------------
     3. NAVIGATION — scrolled state, mobile drawer, More menu
     ---------------------------------------------------------- */
  var nav = $('#site-nav');
  var burger = $('#burger');
  var drawer = $('#mobile-menu');
  var moreBtn = $('#more-btn');
  var moreMenu = $('#more-menu');

  function onScrollNav() {
    if (!nav) { return; }
    nav.classList.toggle('is-scrolled', window.scrollY > 40);
  }

  function setDrawer(open) {
    if (!burger || !drawer) { return; }
    burger.setAttribute('aria-expanded', open ? 'true' : 'false');
    burger.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
    drawer.hidden = !open;
    document.body.style.overflow = open ? 'hidden' : '';
  }

  if (burger) {
    burger.addEventListener('click', function () {
      setDrawer(burger.getAttribute('aria-expanded') !== 'true');
    });
  }

  function setMore(open) {
    if (!moreBtn || !moreMenu) { return; }
    moreBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    moreMenu.hidden = !open;
  }

  if (moreBtn) {
    moreBtn.addEventListener('click', function (event) {
      event.stopPropagation();
      setMore(moreBtn.getAttribute('aria-expanded') !== 'true');
    });
  }

  document.addEventListener('click', function (event) {
    if (moreMenu && !moreMenu.hidden && !moreMenu.contains(event.target) && event.target !== moreBtn) {
      setMore(false);
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') { return; }
    setMore(false);
    if (burger && burger.getAttribute('aria-expanded') === 'true') {
      setDrawer(false);
      burger.focus();
    }
  });

  // Close the drawer when any in-page link is used
  $$('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function () {
      setDrawer(false);
      setMore(false);
    });
  });

  /* ----------------------------------------------------------
     4. REVEAL ON SCROLL (respects reduced motion)
     ---------------------------------------------------------- */
  var revealItems = $$('.reveal');
  if (reduceMotion || !('IntersectionObserver' in window)) {
    revealItems.forEach(function (el) { el.classList.add('is-in'); });
  } else {
    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-in');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    revealItems.forEach(function (el) { revealObserver.observe(el); });
  }

  /* ----------------------------------------------------------
     5. NUMBER COUNTERS (only when motion is allowed)
     ---------------------------------------------------------- */
  var counters = $$('[data-count-to]');
  function runCounter(el) {
    var target = parseFloat(el.getAttribute('data-count-to'));
    var decimals = parseInt(el.getAttribute('data-decimals') || '0', 10);
    if (isNaN(target)) { return; }
    if (reduceMotion) { el.textContent = target.toFixed(decimals); return; }
    var start = null;
    var duration = 1400;
    function step(timestamp) {
      if (start === null) { start = timestamp; }
      var p = Math.min((timestamp - start) / duration, 1);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = (target * eased).toFixed(decimals);
      if (p < 1) { window.requestAnimationFrame(step); }
      else { el.textContent = target.toFixed(decimals); }
    }
    window.requestAnimationFrame(step);
  }
  if (counters.length) {
    if (!('IntersectionObserver' in window)) {
      counters.forEach(runCounter);
    } else {
      var countObserver = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            runCounter(entry.target);
            countObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.4 });
      counters.forEach(function (el) { countObserver.observe(el); });
    }
  }

  /* ----------------------------------------------------------
     6. HERO PARALLAX — a very small, capped movement
     ---------------------------------------------------------- */
  var parallaxEl = $('[data-parallax]');
  if (parallaxEl && !reduceMotion) {
    var ticking = false;
    var updateParallax = function () {
      var y = Math.min(window.scrollY * 0.25, 72);
      parallaxEl.style.setProperty('--py', y.toFixed(1) + 'px');
      ticking = false;
    };
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; window.requestAnimationFrame(updateParallax); }
    }, { passive: true });
    updateParallax();
  }

  /* ----------------------------------------------------------
     7. SCROLLSPY — highlights the section you are reading
     ---------------------------------------------------------- */
  var inPageLinks = $$('.nav__link[href^="#"], .nav__more-menu a[href^="#"], .mobile-menu__list a[href^="#"]');
  var sections = inPageLinks.map(function (link) {
    var id = link.getAttribute('href').slice(1);
    return id ? document.getElementById(id) : null;
  }).filter(Boolean);

  if (sections.length && 'IntersectionObserver' in window) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) { return; }
        var id = entry.target.id;
        inPageLinks.forEach(function (link) {
          var isCurrent = link.getAttribute('href') === '#' + id;
          link.classList.toggle('is-active', isCurrent);
          if (isCurrent) { link.setAttribute('aria-current', 'true'); }
          else { link.removeAttribute('aria-current'); }
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    sections.forEach(function (section) { spy.observe(section); });
  }

  /* ----------------------------------------------------------
     8. ILLUSTRATIVE MAP — region buttons and hover states
     ---------------------------------------------------------- */
  var mapList = $('#map-list');
  var mapNoteTitle = $('#map-note-title');
  var mapNoteText = $('#map-note-text');
  if (mapList && mapNoteTitle && mapNoteText) {
    var mapButtons = $$('.map-list__btn', mapList);
    var regions = $$('.india-region');
    var numbers = $$('.india-map__num');

    var select = function (index, focusNote) {
      mapButtons.forEach(function (btn) {
        var on = btn.getAttribute('data-region') === index;
        btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
      regions.forEach(function (path) {
        path.classList.toggle('is-active', path.getAttribute('data-region') === index);
      });
      numbers.forEach(function (num) {
        var match = num.getAttribute('data-number') === index;
        num.setAttribute('opacity', match ? '0' : '.85');
      });
      var active = mapButtons.filter(function (b) { return b.getAttribute('data-region') === index; })[0];
      if (active) {
        mapNoteTitle.textContent = active.getAttribute('data-title') || '';
        mapNoteText.textContent = active.getAttribute('data-text') || '';
        if (focusNote) { mapNoteTitle.setAttribute('tabindex', '-1'); mapNoteTitle.focus({ preventScroll: true }); }
      }
    };

    mapButtons.forEach(function (btn) {
      var index = btn.getAttribute('data-region');
      btn.addEventListener('click', function () { select(index, false); });
      btn.addEventListener('mouseenter', function () { select(index, false); });
      btn.addEventListener('focus', function () { select(index, false); });
    });

    regions.forEach(function (path) {
      var index = path.getAttribute('data-region');
      path.addEventListener('mouseenter', function () { select(index, false); });
      path.addEventListener('focus', function () { select(index, false); });
      path.addEventListener('click', function () { select(index, false); });
      path.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          select(index, false);
        }
      });
    });
  }

  /* ----------------------------------------------------------
     9. DOCUMENTARY — lazy player, share and copy actions
     ---------------------------------------------------------- */
  var video = $('#video');
  var videoFrame = $('#video-frame');
  var playBtn = $('#video-play');
  var videoHint = $('#video-hint');

  function videoUrl() {
    return video ? (video.getAttribute('data-video-url') || '').trim() : '';
  }
  function hasRealUrl() {
    var url = videoUrl();
    return url.length > 0 && url.indexOf('[') === -1 && /^https?:\/\//i.test(url);
  }
  function embedUrl(url) {
    // Accept youtube.com/watch?v=, youtu.be/, /embed/, /shorts/ and bare IDs
    var id = '';
    var patterns = [
      /[?&]v=([A-Za-z0-9_-]{6,})/,
      /youtu\.be\/([A-Za-z0-9_-]{6,})/,
      /\/embed\/([A-Za-z0-9_-]{6,})/,
      /\/shorts\/([A-Za-z0-9_-]{6,})/
    ];
    for (var i = 0; i < patterns.length; i += 1) {
      var match = url.match(patterns[i]);
      if (match) { id = match[1]; break; }
    }
    if (!id && /^[A-Za-z0-9_-]{6,}$/.test(url)) { id = url; }
    return id ? 'https://www.youtube-nocookie.com/embed/' + id + '?rel=0&enablejsapi=1' : '';
  }

  /* YouTube blocks its player in two situations this site can detect reliably:
       - the page is open straight from a file, so there is no web address to
         send as a referrer;
       - the page sits inside a sandboxed frame, which browsers expose as an
         opaque "null" origin — this is how most in-app preview panes work.
     In both cases we show our own panel with a direct link, instead of leaving
     the visitor looking at YouTube's blocked-content box. On a normally hosted
     website none of this runs and the player loads as usual. */
  function blockedReason() {
    try {
      if (location.protocol === 'file:') { return 'file'; }
      if (window.origin === 'null') { return 'sandbox'; }
    } catch (err) { return 'sandbox'; }
    return '';
  }

  function fallbackMarkup(reason) {
    var url = videoUrl();
    var why;
    if (reason === 'sandbox') {
      why = 'This page is open inside a restricted preview pane, where YouTube does not allow in-page playback. On the published website the documentary plays right here.';
    } else if (reason === 'file') {
      why = 'The page is open directly from a file, and YouTube only allows in-page playback on a published web address.';
    } else {
      why = 'In-page playback is unavailable here.';
    }
    return '<div class="video__fallback">' +
      '<svg class="ico ico--xl" aria-hidden="true"><use href="#i-youtube"></use></svg>' +
      '<p class="video__fallback-title">Watch the documentary on YouTube</p>' +
      '<p class="video__fallback-text">' + why + '</p>' +
      '<p><a class="btn btn--gold" href="' + url + '" target="_blank" rel="noopener noreferrer">' +
      'Watch on YouTube <svg class="ico" aria-hidden="true"><use href="#i-external"></use></svg></a></p>' +
      '<p class="video__fallback-url">Direct link: <a href="' + url + '" target="_blank" rel="noopener noreferrer">' +
      url.replace(/^https?:\/\//, '') + '</a></p>' +
      '</div>';
  }

  function showFallback(reason) {
    if (!videoFrame) { return; }
    videoFrame.innerHTML = fallbackMarkup(reason);
    if (videoHint) {
      videoHint.textContent = 'In-page playback is unavailable here. The direct link above always works, and the player appears normally on the published website.';
    }
  }

  function mountPlayer() {
    if (!videoFrame) { return; }
    var src = embedUrl(videoUrl());
    if (!src) { toast('That link does not look like a YouTube video link.'); return; }

    var reason = blockedReason();
    if (reason) { showFallback(reason); return; }

    videoFrame.innerHTML =
      '<iframe src="' + src + '" title="Guardians of the Forest — student documentary" ' +
      'loading="lazy" allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" ' +
      'referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>';
    if (videoHint) { videoHint.textContent = 'Playing inside this page. Use the full-screen button in the player for a larger view.'; }
  }

  if (playBtn) {
    playBtn.addEventListener('click', function () {
      if (!hasRealUrl()) {
        toast('Add your YouTube link first: replace [PASTE YOUTUBE VIDEO LINK HERE] in the site file.');
        return;
      }
      mountPlayer();
    });
  }

  function pageShareUrl() {
    if (location.protocol === 'http:' || location.protocol === 'https:') { return location.href; }
    return ''; // opened directly from disk — no shareable URL yet
  }

  function sharePayload() {
    var url = hasRealUrl() ? videoUrl() : pageShareUrl();
    return {
      title: 'Guardians of the Forest',
      text: 'Guardians of the Forest — role of tribal communities in protecting forests and natural resources.',
      url: url
    };
  }

  function doShare() {
    var payload = sharePayload();
    if (navigator.share) {
      navigator.share(payload).catch(function () { /* visitor cancelled — nothing to do */ });
      return;
    }
    if (!payload.url) {
      toast('Sharing needs a published web address. Copy the link after you upload the site.');
      return;
    }
    copyText(payload.url).then(function () {
      toast('Link copied. Paste it in a message to share the project.');
    }).catch(function () {
      toast('Could not copy automatically. Please copy the address from your browser.');
    });
  }

  function doCopyVideo() {
    if (!hasRealUrl()) {
      var fallback = pageShareUrl();
      if (fallback) {
        copyText(fallback).then(function () {
          toast('The documentary link is not set yet, so the page link was copied instead.');
        }).catch(function () { toast('Could not copy the link automatically.'); });
      } else {
        toast('Add your YouTube link first, then this button will copy it.');
      }
      return;
    }
    copyText(videoUrl()).then(function () {
      toast('Video link copied to the clipboard.');
    }).catch(function () {
      toast('Could not copy automatically. Please copy the link from your browser.');
    });
  }

  $$('[data-action]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var action = btn.getAttribute('data-action');
      if (action === 'share') { doShare(); }
      if (action === 'copy-video') { doCopyVideo(); }
      if (action === 'watch-youtube') {
        if (!hasRealUrl()) {
          toast('Add your YouTube link first: replace [PASTE YOUTUBE VIDEO LINK HERE] in the site file.');
          return;
        }
        window.open(videoUrl(), '_blank', 'noopener');
      }
    });
  });

  /* ----------------------------------------------------------
     10. PLACEHOLDER SOCIAL BUTTONS — friendly reminder
     ---------------------------------------------------------- */
  $$('.social[data-placeholder]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      toast('Reminder: add your ' + btn.getAttribute('data-placeholder') + ' in the footer, then turn this button into a normal link.');
    });
  });

  /* ----------------------------------------------------------
     11. BACK TO TOP
     ---------------------------------------------------------- */
  var toTop = $('#to-top');
  if (toTop) {
    toTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' });
      var firstHeading = $('#hero-title');
      if (firstHeading) { firstHeading.setAttribute('tabindex', '-1'); firstHeading.focus({ preventScroll: true }); }
    });
  }

  function onScrollUi() {
    if (toTop) { toTop.classList.toggle('is-visible', window.scrollY > 700); }
  }

  /* ----------------------------------------------------------
     12. FOOTER YEAR
     ---------------------------------------------------------- */
  var yearEl = $('#year');
  if (yearEl) { yearEl.textContent = String(new Date().getFullYear()); }

  /* ----------------------------------------------------------
     13. SCROLL LISTENERS
     ---------------------------------------------------------- */
  var scheduled = false;
  window.addEventListener('scroll', function () {
    if (scheduled) { return; }
    scheduled = true;
    window.requestAnimationFrame(function () {
      onScrollNav();
      onScrollUi();
      scheduled = false;
    });
  }, { passive: true });

  onScrollNav();
  onScrollUi();
})();
